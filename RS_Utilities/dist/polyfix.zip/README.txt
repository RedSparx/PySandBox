polyfix v0.1: c. 2018 RedSparx

Description:
-----------
This program attempts to fix Eagle SCR files that
do not have complete polygon coordinates.  It will
search and fix only POLYGON commands.  The file may
then be run directly in eagle.


Usage:
-----
polyfix <inputfile.scr> <outputfile.scr>

If no output file is provided, 'output.scr' will be
used by default.

